import java.io.File;
import java.io.IOException;
import java.util.HashSet;


public class FileOS {
    private String name = "localhost";
    private HashSet<User> UserList = new HashSet<>();

    public FileOS() {

    }

    public String getName() {
        return this.name;
    }

    public void addUser(User user) throws IOException {
        UserList.add(user);
    }
}
