
import java.io.IOException;
import java.util.Scanner;

public class Appliction {

    private static final String exit = "exit";
    private static final String create = "create";
    private static final String delete = "delete";
    private static final String read = "read";
    private static final String write = "write";
    private static final String ls = "ls";
    private static final String clear = "clear";

    static Scanner in = new Scanner(System.in);

    public static void showBlue(String chars) {
        System.out.print("\033[1;94m" + chars + "\033[m");
    }

    public static void show(String userName, String serverName) {
        System.out.print("[" + userName + "@" + serverName + "]" + ":");
        showBlue("~");
        System.out.print("$ ");
    }

    public static void run(User user, FileOS OS) throws IOException {
        String command = "";
        String fileName = "";
        while (true) {
            switch (command) {
                case clear:
                    FileFunction.clear();
                    show(user.getName(), OS.getName());
                    break;
                case ls:
                    FileFunction.ls();
                    System.out.println();
                    show(user.getName(), OS.getName());
                    break;
                case create:
                    FileFunction.create(fileName);
                    show(user.getName(), OS.getName());
                    break;
                case delete:
                    FileFunction.delete(fileName);
                    show(user.getName(), OS.getName());
                    break;
                case read:
                    FileFunction.read(fileName);
                    System.out.println();
                    show(user.getName(), OS.getName());
                    break;
                case write:
                    FileFunction.write(fileName);
                    show(user.getName(), OS.getName());
                    break;
                default:
                    show(user.getName(), OS.getName());
            }
            command = in.next();
            if (command.equals(exit))
                break;
            if (command.equals(ls) || command.equals(clear)) {
                continue;
            }
            fileName = in.next();
        }
    }

    public static void login() throws IOException {
        FileOS start = new FileOS();
        String name, block;
        String password;
        User user;
        while (true) {
            block = in.nextLine();
            System.out.print("log in:");
            name = in.nextLine();
            System.out.print("password:");
            password = in.nextLine();
            user = new User(name, password);
            run(user, start);
        }
    }


    public static void main(String[] args) throws IOException {
        login();
    }

}
