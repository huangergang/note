import java.io.*;
import java.nio.charset.StandardCharsets;
import java.sql.Statement;
import java.util.Scanner;

public class FileFunction {
    static Scanner in = new Scanner(System.in);

    //显示所有文件
    public static void ls() {
        File file = new File("hemo/");
        File[] files = file.listFiles();
        for (File f : files
        ) {
            String fileName = f.getPath().substring(5);
            System.out.print(fileName + "   ");
        }

    }

    // 创建文件
    public static File create(String fileName) throws IOException {
        String fileString;
        fileString = "hemo/" + fileName;
        File file = new File(fileString);
        file.createNewFile();
        return file;
    }

    // 删除文件或目录
    public static void delete(String fileName) throws IOException {
        create(fileName).delete();
    }

    // 读文件
    public static void read(String fileName) throws IOException {
        BufferedInputStream bufferedInputStream = new BufferedInputStream(new FileInputStream(create(fileName)));
        int by;
        while ((by = bufferedInputStream.read()) != -1) {
            System.out.print((char) by);
        }
        bufferedInputStream.close();
    }

    // 写文件
    public static void write(String fileName) throws IOException {
        String text = in.nextLine();
        BufferedOutputStream bufferedOutputStream = new BufferedOutputStream(new FileOutputStream(create(fileName), true));
        byte[] bytes = text.getBytes();
        bufferedOutputStream.write(bytes);
        bufferedOutputStream.close();
    }

    public static void clear(){
        for (int i = 0; i < 50; i++) {
            System.out.println();
        }
    }

}
